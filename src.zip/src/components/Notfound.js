import react from "react";
const Notfound = () => {
    return ( <div>
        <h1>Notfound</h1>
    </div> 
    );
}
 
export default Notfound;